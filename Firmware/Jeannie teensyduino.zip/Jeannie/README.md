# Instructions

The source code requires Teensyduino from [PJRC](https://pjrc.com) to compile. You also need CircularBuffer from Agileware and Adafruit_GFX, which are available in the Arduino Library Manager. Compile with 'Serial + MIDI + Audio'.
